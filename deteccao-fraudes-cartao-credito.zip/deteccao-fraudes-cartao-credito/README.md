# Detecção de Fraudes em Cartões de Crédito

Projeto de Machine Learning para classificar transações de cartão de crédito como normais ou potencialmente fraudulentas, com foco em dados altamente desbalanceados.

## Objetivo

A base clássica contém 284.807 transações e 492 fraudes (cerca de 0,172%). Nesse cenário, a acurácia pode parecer alta mesmo se o modelo não detectar nenhuma fraude. Por isso, a avaliação prioriza **precisão, recall, F1-score e Average Precision**, além de ROC-AUC, matriz de confusão e quantidade de falsos negativos e falsos positivos.

## Tecnologias

- Python, Jupyter Notebook
- Pandas e NumPy
- Scikit-learn
- Imbalanced-learn (RandomUnderSampler e SMOTE)
- XGBoost
- Matplotlib e Seaborn
- SHAP

## Estrutura

```text
deteccao-fraudes-cartao-credito/
├── notebooks/
│   └── deteccao_fraudes.ipynb
├── data/                  # baixada localmente; não vai para o GitHub
├── requirements.txt
├── .gitignore
└── README.md
```

## Como executar

### 1. Clonar o repositório

```bash
git clone https://github.com/SEU-USUARIO/deteccao-fraudes-cartao-credito.git
cd deteccao-fraudes-cartao-credito
```

### 2. Criar e ativar um ambiente virtual (opcional, recomendado)

Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Instalar as dependências

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Abrir e executar o notebook

```bash
jupyter notebook
```

Abra `notebooks/deteccao_fraudes.ipynb` e execute as células de cima para baixo. O notebook baixa automaticamente a base pública para `data/raw/creditcard.csv` na primeira execução. O download tem aproximadamente 150 MB e requer conexão com a internet. Se a Aula 1 indicar uma URL direta diferente, altere `DATASET_URL` na seção de carregamento.

> Execute todas as células e salve o notebook após a execução para que gráficos, tabelas e resultados apareçam no arquivo submetido.

## O que foi feito

1. **Exploração:** dimensões da base, tipos, valores ausentes e proporção de cada classe.
2. **Preparação:** criação de `Amount_log = log1p(Amount)`, divisão estratificada em treino (70%), validação (15%) e teste (15%) e padronização ajustada somente no treino.
3. **Modelagem:** Regressão Logística com `class_weight="balanced"`, Random Forest com `class_weight="balanced_subsample"` e XGBoost com `scale_pos_weight` calculado no treino.
4. **Limiar:** seleção do limiar que maximiza F1 na validação; o conjunto de teste não é usado para escolher o limiar nem o modelo vencedor.
5. **Avaliação:** comparação da classe de fraude por precisão, recall e F1, Average Precision, ROC-AUC, falsos negativos e falsos positivos; curvas ROC e Precisão–Recall e matriz de confusão.
6. **Reamostragem:** comparação de Random Undersampling e SMOTE usando apenas os dados de treino.
7. **Explicabilidade:** importâncias de variáveis e SHAP local/global para o XGBoost.

## Resultados

Os números devem ser registrados **depois de executar o notebook**. Use a tabela `teste_df` exibida na seção “Avaliação final no conjunto de teste” para completar esta tabela com os valores reais do experimento. Não preencha métricas estimadas ou inventadas.

| Modelo | Limiar | Precisão (fraude) | Recall (fraude) | F1 (fraude) | Average Precision |
|---|---:|---:|---:|---:|---:|
| Regressão Logística | — | — | — | — | — |
| Random Forest | — | — | — | — | — |
| XGBoost | — | — | — | — | — |

**Modelo escolhido pela validação:** preencher após executar.  
**Justificativa do limiar:** explicar a relação entre fraudes detectadas e falsos alertas.  
**O que o SHAP mostrou:** registrar as variáveis que mais contribuíram para a previsão analisada.

## Interpretação e limitações

- **Recall** mede a proporção das fraudes reais que o modelo conseguiu sinalizar; recall baixo significa fraudes perdidas.
- **Precisão** indica quantos alertas emitidos eram realmente fraudes; precisão baixa pode gerar muitos falsos alertas.
- **F1-score** equilibra precisão e recall. O melhor limiar depende do custo relativo de fraudes perdidas e alertas incorretos.
- `V1` a `V28` são componentes PCA anonimizados; não é correto atribuir a eles um significado de negócio que a base não fornece.
- SHAP explica a contribuição das variáveis para a saída do modelo, não prova causalidade e não confirma que uma transação seja fraude.
- A base cobre transações observadas em um período histórico limitado. Resultados acadêmicos não garantem desempenho em transações futuras ou em outras instituições.

## Fonte dos dados

- [Zenodo — Credit Card Fraud Detection](https://zenodo.org/records/7395559)
- [Kaggle — mlg-ulb/creditcardfraud](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)

Dados não são incluídos neste repositório por causa do tamanho do arquivo. O notebook obtém uma cópia pública a partir do link de download e armazena-a apenas localmente.

## Diferenças/decisões deste projeto

- Usei conjunto separado de validação para selecionar o limiar, evitando ajustar o limiar no teste.
- Comparei Regressão Logística, Random Forest e XGBoost com estratégias de peso de classe.
- Acrescentei uma comparação experimental entre undersampling e SMOTE, aplicados somente ao treino.
- Usei Average Precision junto com recall, precisão e F1, pois a classe positiva é muito rara.
- Acrescentei explicabilidade local com SHAP e visualização global das contribuições.

## Licença e uso

Projeto educacional. Não use esse modelo isoladamente para bloquear transações reais ou tomar decisões financeiras. Verifique os termos da fonte original antes de redistribuir os dados.
